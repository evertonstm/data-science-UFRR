n1 = float(input("Digite o primeiro numero: "))
n2 = float(input("Digite o segundo numero: "))

soma = n1 + n2
sub = n1 - n2
mult = n2 * n2
div = n1 / n2

print("soma é ",soma)
print("subtração é ",sub)
print("multiplicação é ",mult)
print("divisão é ",div)